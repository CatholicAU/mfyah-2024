<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package MFYAH_2024
 */

get_header();
?>

	<section id="primary">
		<main id="main">

			<?php
			/* Start the Loop */
			while ( have_posts() ) :
				the_post();
				get_template_part( 'template-parts/content/content', 'single' );

				if ( is_singular( 'post' ) ) {
					// Previous/next post navigation.
					the_post_navigation(
						array(
							'next_text' => '<span aria-hidden="true">' . __( 'Next Post', 'mfyah-2024' ) . '</span> ' .
								'<span class="sr-only">' . __( 'Next post:', 'mfyah-2024' ) . '</span> <br/>' .
								'<span></span>',
							'prev_text' => '<span aria-hidden="true">' . __( 'Previous Post', 'mfyah-2024' ) . '</span> ' .
								'<span class="sr-only">' . __( 'Previous post:', 'mfyah-2024' ) . '</span> <br/>' .
								'<span></span>',
						)
					);
				}

				// If comments are open, or we have at least one comment, load
				// the comment template.
				// if ( comments_open() || get_comments_number() ) {
				// 	comments_template();
				// }

				// End the loop.
			endwhile;
			?>

		</main><!-- #main -->
	</section><!-- #primary -->

<?php
get_footer();
